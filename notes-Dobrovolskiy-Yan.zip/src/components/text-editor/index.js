import TextEditor from './text-editor';
export default TextEditor;
