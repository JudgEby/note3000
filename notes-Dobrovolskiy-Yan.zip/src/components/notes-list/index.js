import NotesList from './notes-list';
export default NotesList;
