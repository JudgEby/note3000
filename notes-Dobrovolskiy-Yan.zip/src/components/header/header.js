import React from 'react';
import './header.css';

const Header = () => {
	return <header className='header'>NOTEPAD 3000</header>;
};
export default Header;
